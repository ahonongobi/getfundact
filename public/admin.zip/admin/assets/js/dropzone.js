(function($) {
    "use strict";
    $("my-awesome-dropzone").dropzone({
        url: "Bootstrapdash.com/"
    });
})(jQuery);
