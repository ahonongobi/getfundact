<?php

use App\Http\Controllers\BanqucaireController;
use App\Http\Controllers\CampagneController;
use App\Http\Controllers\ChangePasswordController;
use App\Http\Controllers\CNIController;
use App\Http\Controllers\ContrubutionController;
use App\Http\Controllers\EditController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\MainController;
use App\Http\Controllers\OrgController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RegisterController;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('login',[LoginController::class,'view'])->name('login');
Route::get('register',[RegisterController::class,'view'])->name('regiter');
Route::get('about',[MainController::class,'view'])->name('about');


//post route start here 
Route::post('register',[RegisterController::class,'register'])->name('regiter.post');
Route::post('login',[LoginController::class,'login']);
Route::get('auth/google', [LoginController::class,'redirectToGoogle']);
Route::get('auth/google/callback', [LoginController::class,'handleGoogleCallback']);

Route::get('auth/facebook', [LoginController::class,'redirectToFacebook']);
Route::get('auth/facebook/callback', [LoginController::class,'handleFacebookCallback']);

//middleware route
Route::group(["middleware"=>"auth"],function(){
Route::get('my_space',[MainController::class,'indexUserDash']);
Route::get('campagne',[MainController::class,'indexCampagne']);
Route::get('profile',[MainController::class,'profile']);
Route::get('/my-campagne',[MainController::class,'myCampagne'])->name('my-campagne');
Route::get('/donation-details/{id}/{name}',[MainController::class,'donationDetails'])->name('donation-details');
Route::get('/donation-details-org/{id}/{name}',[MainController::class,'donationDetailsOrg'])->name('donation-details');

Route::get('/contributions',[MainController::class,'contributions'])->name('contributionss');
Route::get('/logout',[LoginController::class,'logout']);
Route::get('/edit/{id}',[EditController::class,'edit']);


//route org
Route::get('/my_org',[OrgController::class,'index']);
Route::get('/profile-org',[OrgController::class,'profileOrg']);
Route::get('/contributions-org',[OrgController::class,'contributionsOrg']);

Route::get('/my-campagne-org',[OrgController::class,'mycampagneOrg'])->name('my-campagne-org');


//post
Route::post('addProfile',[ProfileController::class,'addProfile']);
Route::post('addBancaire',[BanqucaireController::class,'addBancaire']);
Route::post('changePassword',[ChangePasswordController::class,'updatePassword']);
Route::post('cni',[CNIController::class,'sendCNI']);
Route::post('addcampagnes',[CampagneController::class,'addCamapagnes']);
Route::post('/editcampagnes/{id}',[EditController::class,'editPost']);
Route::post('/contribution',[ContrubutionController::class,'sendMoney']);





});
