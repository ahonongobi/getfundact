<?php $__env->startSection('content'); ?>
  
      <div class="container">
        <div class="details-payment">
            <h3>Contribution</h3>
            <form method="POST" action="<?php echo e(url('withdrawal')); ?>">
                <?php echo csrf_field(); ?>
                
                

                <div class="form-input-area">
                    <div class="col-lg-12 mb-4">
                        <div class="form-group mb-5">
                            
                              
                                <select name="nom_campagne" class="mb-4 form-group">
                                    <option>Veuillez selectionner le rétrait que vous souhaitez effectué :) </option>
                                    <option value="all">Je veux retirer tout mes sous</option>
                                    <?php $__currentLoopData = $withdrawalinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>-<?php echo e($item->name); ?>"><?php echo e($item->name); ?>/ <?php echo e($item->created_at); ?>/ $<?php echo e($item->montant_cotise ?? '0'); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </select>
                              
                         </div>
                    </div>
                    
                    
                    
                    <div class="text-center mt-3 mb-3">
                        
                        <button type="submit" class="btn common-btn">Lancer le rétrait</button>

                    
                    </div>
                </div>
            </form>
        </div>
      </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts._user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/user_dash/withdrawal.blade.php ENDPATH**/ ?>