<style>
    tr,td {
        text-align: justify !important;
        width: 50% !important;
    }
    td:first-child{
        font-weight: bold;
    }

</style>
<?php $__env->startSection('content'); ?>


   
                <div class="row">
                    
                </div>

                <div class="row">
                    <div class="d-flex justify-content-between mb-3">
                        <?php if($campagnePost->statut==0): ?>
                        <a href="<?php echo e(url('activePost/'.$campagnePost->id)); ?>" class="btn btn-success ml-3 text-white">Activer </a>

                        <?php else: ?>
                        <a href="<?php echo e(url('unactivePost/'.$campagnePost->id)); ?>" class="btn btn-danger ml-3 text-white">Désactiver </a>

                        <?php endif; ?>
                    </div>
                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <p class="card-title mb-0">Details</p>
                                <table class="table">
                            
                                    <tr>
                                        <td>Categories</td>
                                        <td><?php echo e($campagnePost->categories ?? 'non rensigné'); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Name</td>
                                        <td><?php echo e($campagnePost->name ?? 'non rensigné'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Durée</td>
                                        <td><?php echo e($campagnePost->monnaie ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Montant visé</td>
                                        <td><?php echo e($campagnePost->montant_v ?? 'non rensigné'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Nom du bénéficiaire</td>
                                        <td><?php echo e($campagnePost->name_b ?? 'non rensigné'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Oû depensez l'argent</td>
                                        <td><?php echo e($campagnePost->where ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Detaille</td>
                                        <td><?php echo e($campagnePost->details ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>keys_word</td>
                                        <td><?php echo e($campagnePost->keys_word ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Video</td>
                                        <td><?php echo e($campagnePost->video ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Siteweb</td>
                                        <td><?php echo e($campagnePost->siteweb ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Hashtag</td>
                                        <td><?php echo e($campagnePost->hashtag ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Montant_cotise</td>
                                        <td><?php echo e($campagnePost->montant_cotise ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Statut</td>
                                        <td><?php echo e($campagnePost->statut ?? 'non rensigné'); ?></td>
                                    </tr>
                                </table>
                                 <div class="details">
                                    <tr>
                                        <td class="text-bold"><span style="font-weight: bold;">Details ojectifs</span></td>
                                        <td style="text-align: justify !important">
                                           <?php echo htmlspecialchars_decode($campagnePost->details_ojectifs) ?? 'non rensigné' ?></td>
                                    </tr>

                                    <tr>
                                        <td style="font-weight:bold;"> <span style="font-weight: bold;">Details budgets</span> </td>
                                        <td style="text-align: justify !important">
                                           <?php echo htmlspecialchars_decode($campagnePost->detail_budget) ?? 'non rensigné' ?></td>
                                    </tr>
                                 </div>
                                <div class="d-flex justify-content-between">
                                    
                                    
                                    <a href="<?php echo e(asset('storage/UserDocument/'.$campagnePost->file_vignette)); ?>">
                                        <img width="400" height="300" src="<?php echo e(asset('storage/UserDocument/'.$campagnePost->file_vignette)); ?>" alt="" srcset="">
                                    </a>
                                    <a href="<?php echo e(asset('storage/UserDocument/'.$campagnePost->file_couverture)); ?>">
                                        <img width="400" height="300" src="<?php echo e(asset('storage/UserDocument/'.$campagnePost->file_couverture)); ?>" alt="" srcset="">
                                    </a>
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                
            </div>
        </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/admin/see-more-campagne.blade.php ENDPATH**/ ?>