<?php $__env->startSection('content'); ?>
<div class="benefit-area pt-100 pb-70">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $contribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-lg-3">
                <div class="benefit-item">
                    <img width="100" height="100" src="<?php echo e(asset('/storage/UserPhoto/'.$item->photo)); ?>" alt="" srcset="">
                    <h3><?php echo e($item->name); ?>  </h3>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <div class="col-sm-6 col-lg-3 d-none">
                <div class="benefit-item">
                    <img width="100" height="100" src="<?php echo e(asset('assets/img/anonymous-user.png')); ?>" alt="" srcset="">
                    <h3></h3>
                </div>
            </div>
            
            <div class="col-sm-6 col-lg-3 d-none">
                <div class="benefit-item four">
                    <img width="100" height="100" src="<?php echo e(asset('assets/img/6.png')); ?>" alt="" srcset="">

                    <h3>Education facilities</h3>
                </div>
            </div>

            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts._user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/user_dash/contribution.blade.php ENDPATH**/ ?>