<?php $__env->startComponent('mail::message'); ?>

![Some option text][logo]

   [logo]: <?php echo e(asset('/assets/img/logo.png')); ?> "Logo"

Bonjour <?php echo e($name); ?>,

<?php echo e($message); ?>




L'équipe getfund-act,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/emails/orders/shipped.blade.php ENDPATH**/ ?>