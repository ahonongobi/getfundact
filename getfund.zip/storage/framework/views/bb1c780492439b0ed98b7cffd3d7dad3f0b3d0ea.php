<?php $__env->startSection('content'); ?>
<section class="donations-area two pt-100 pb-70">
    <div class="container">
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success">
           
                <?php echo e(Session::get('success')); ?>

           
        </div>
        <?php endif; ?>
        <div class="section-title">
            <span class="sub-title">GETFUND ACTION</span>
            <h2>Campagnes publics</h2>
   
        </div>
        <div class="row">

            <?php $__currentLoopData = $campagnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-lg-4">
                <div class="donation-item">
                    <div class="img">
                        <img src="<?php echo e(asset('storage/UserDocument/'.$item->file_vignette)); ?>" alt="Donation">
                        <a class="common-btn" href="<?php echo e(url('donation-details/'.$item->id.'/'.$item->name_b)); ?>">Détails</a>
                    </div>
                    <div class="inner">
                        <div class="top">
                            <a class="tags" href="#">#<?php echo e($item->categories); ?></a>
                            <h3>
                                <a href="<?php echo e(url('donation-details')); ?>"><?php echo e($item->name); ?></a>
                            </h3>
                            <p>
                                <?php
                                echo substr($item->details,0,75).'...'
                                ?>
                                
                            </p>
                        </div>
                        <div class="bottom">
                            
                             
                            <?php if($item->montant_cotise==0): ?>
                             <div class="skill">
                                <div class="skill-bar skill0 wow fadeInLeftBig">

                                    
                                    <span class="skill-count0">0%</span>
                                </div>
                            </div>
                             <?php endif; ?>
                            
                            <?php if($item->montant_cotise==(1/10)*$item->montant_v): ?>
                            <div class="skill">
                                <div class="skill-bar skill10 wow fadeInLeftBig">

                                    
                                    <span class="skill-count10">10%</span>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if($item->montant_cotise==(1/20)*$item->montant_v): ?>
                            <div class="skill">
                                <div class="skill-bar skill20 wow fadeInLeftBig">

                                    
                                    <span class="skill-count20">20%</span>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if($item->montant_cotise==(1/50)*$item->montant_v): ?>
                            <div class="skill">
                               
                                <div class="skill-bar skill50 wow fadeInLeftBig">

                                    <span class="skill-count50">50%</span>
                                </div>
                            </div>     
                            <?php endif; ?>
                            
                            <?php if($item->montant_cotise==(1/75)*$item->montant_v): ?>
                            <div class="skill">
                                <div class="skill-bar skill75 wow fadeInLeftBig">

                                    
                                    <span class="skill-count75">75%</span>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if($item->montant_cotise==(1/85)*$item->montant_v): ?>
                            <div class="skill">
                                <div class="skill-bar skill1 wow fadeInLeftBig">

                                    <span class="skill-count1">85%</span>
                                    
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if($item->montant_cotise==(1/95)*$item->montant_v): ?>
                            <div class="skill">
                                <div class="skill-bar skill95 wow fadeInLeftBig">

                                    <span class="skill-count95">95%</span>
                                    
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if($item->montant_cotise==$item->montant_v): ?>
                            <div class="skill">
                                <div class="skill-bar skill100 wow fadeInLeftBig">

                                    <span class="skill-count100">100%</span>
                                    
                                </div>
                            </div>
                            <?php endif; ?>

                            
                            <ul>
                                <li>Montant contribué:  <?php
                                    if($item->montant_cotise==NULL)
                                    echo "0 FCFA";

                                    else {
                                        echo $item->montant_cotise.' FCFA';
                                    }
                                ?></li>
                                <li>Montant visé: <?php echo e($item->montant_v); ?> FCFA</li>
                            </ul>
                            <h4 class=""> 
                                Contributions:<span> 60 personnes</span>
                                <a href="<?php echo e(url('edit/'.$item->id)); ?>" style="text-decoration: none; color: #d45214; cursor: pointer;" class="ml-10"><i class="icofont-edit"></i></a>
                                <a onclick="return confirm('Cette action est irréversible')" href="<?php echo e(url('delete-post/'.$item->id)); ?>" style="text-decoration: none; color: #d45214; cursor: pointer;" class="ml-10"><i class="icofont-trash"></i></a>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts._user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/user_dash/my-campagne.blade.php ENDPATH**/ ?>