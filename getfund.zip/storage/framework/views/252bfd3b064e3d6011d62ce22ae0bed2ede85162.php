<?php $__env->startSection('content'); ?>


   
                <div class="row">
                    
                </div>

                <div class="row">
                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <p class="card-title mb-0">Utilisateurs</p>
                                <div class="table-responsive">
                                    <table class="table table-striped table-borderless">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Categories</th>
                                                <th>Duree</th>
                                                <th>Montant visé</th>
                                                <th>Name bénéficiaire </th>
                                                <th>Montant cotisés </th>
                                                <th>Ou l'argent sera depensé </th>
                                                <th>Statut </th>
                                                <th>Décision du Jury</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $__currentLoopData = $admin_all_campagne_inactif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                            <td><?php echo e($item->name); ?></td>
                                            <td class="font-weight-bold"><?php echo e($item->categories); ?></td>
                                            <td><?php echo e($item->duree); ?></td>
                                            
                                            <td>

                                                <button class="btn btn-warning rounded-0 text-white">$<?php echo e($item->montant_v); ?></button>

                                            </td>
                                            <td class="d-flex justify-content-evenly">
                                                
                                                   <?php echo e($item->name_b); ?>

                                            </td>
                                            <td>
                                                $<?php echo e($item->montant_cotise ?? '0'); ?>


                                            </td>
                                            <td>

                                                <?php echo e($item->where); ?>


                                            </td>
                                            <?php if($item->statut ==1): ?>
                                            <td class="font-weight-medium text-success">Actif</td>
                                            <?php elseif($item->states ==0): ?>
                                            
                                            <td class="font-weight-medium text-warning">En attente</td>
                                            <?php elseif($item->states == 2): ?>
                                            <td class="font-weight-medium text-danger">Inactif</td>
                                            <?php endif; ?>
                                            <td>

                                                <a href="<?php echo e(url('see-more-campagne/'.$item->id)); ?>" class="btn btn-warning rounded-0 text-white"><i class="ti-eye menu-icon"></i></a>

                                            </td>
                                        </tr>  
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                        </tbody>
                                    </table>

                                   <div class="d-flex justify-content-center"> <?php echo $admin_all_campagne_inactif->links(); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/admin/campagnes-inactif.blade.php ENDPATH**/ ?>