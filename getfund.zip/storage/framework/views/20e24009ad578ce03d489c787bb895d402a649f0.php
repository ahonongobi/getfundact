<style>
    tr,td {
        text-align: justify;
        width: 50%;
    }
    td:first-child{
        font-weight: bold;
    }

</style>
<?php $__env->startSection('content'); ?>


   
                <div class="row">
                    
                </div>

                <div class="row">
                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <p class="card-title mb-0">Utilisateurs</p>
                                <table class="table">
                            
                                    <tr>
                                        <td>Nom et Prénoms</td>
                                        <td><?php echo e($users->nom_prenoms ?? 'non rensigné'); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Date de naissance</td>
                                        <td><?php echo e($users->date_naissance ?? 'non rensigné'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Nationalité</td>
                                        <td><?php echo e($users->nationanlite ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Pays</td>
                                        <td><?php echo e($users->pays ?? 'non rensigné'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td><?php echo e($users->email ?? 'non rensigné'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Téléphone</td>
                                        <td><?php echo e($users->tel ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Adresse</td>
                                        <td><?php echo e($users->votre_adresse ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Region</td>
                                        <td><?php echo e($users->region ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Code postal</td>
                                        <td><?php echo e($users->code_postal ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Numero de compte</td>
                                        <td><?php echo e($users->numero_compte ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Numero institution</td>
                                        <td><?php echo e($users->numero_institution ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Iban</td>
                                        <td><?php echo e($users->iban ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Bic</td>
                                        <td><?php echo e($users->bic ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Nom de banque</td>
                                        <td><?php echo e($users->nom_banque ?? 'non rensigné'); ?></td>
                                    </tr><tr>
                                        <td>Code agence</td>
                                        <td><?php echo e($users->code_agence ?? 'non rensigné'); ?></td>
                                    </tr>
                                </table>

                                <div class="d-flex justify-content-between">
                                    <?php if($usersCount !=0): ?>
                                    <a href="<?php echo e(asset('storage/UserPhoto/'.$users->photo)); ?>">

                                        <img src="<?php echo e(asset('storage/UserPhoto/'.$users->photo)); ?>" alt="" srcset="">
                                    </a>
                                    <a href="<?php echo e(asset('storage/UserDocument/'.$users->cni)); ?>">
                                        <img width="400" height="300" src="<?php echo e(asset('storage/UserDocument/'.$users->cni)); ?>" alt="" srcset="">
                                    </a>
                                    <a href="<?php echo e(asset('storage/UserDocument/'.$users->s_cni)); ?>">
                                        <img width="400" height="300" src="<?php echo e(asset('storage/UserDocument/'.$users->s_cni)); ?>" alt="" srcset="">
                                    </a>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <p class="card-title mb-0">Ses campagnes</p>
                                <div class="table-responsive">
                                    <table class="table table-striped table-borderless">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Categories</th>
                                                <th>Duree</th>
                                                <th>Montant visé</th>
                                                <th>Name bénéficiaire </th>
                                                <th>Montant cotisés </th>
                                                <th>Ou l'argent sera depensé </th>
                                                <th>Statut </th>
                                                <th>Décision du Jury</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $__currentLoopData = $hisCampagnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                            <td><?php echo e($item->name); ?></td>
                                            <td class="font-weight-bold"><?php echo e($item->categories); ?></td>
                                            <td><?php echo e($item->duree); ?></td>
                                            
                                            <td>

                                                <button class="btn btn-warning rounded-0 text-white">$<?php echo e($item->montant_v); ?></button>

                                            </td>
                                            <td class="d-flex justify-content-evenly">
                                                
                                                   <?php echo e($item->name_b); ?>

                                            </td>
                                            <td>
                                                $<?php echo e($item->montant_cotise ?? '0'); ?>


                                            </td>
                                            <td>

                                                <?php echo e($item->where); ?>


                                            </td>
                                            <?php if($item->statut ==1): ?>
                                            <td class="font-weight-medium text-success">Actif</td>
                                            <?php elseif($item->statut ==0): ?>
                                            
                                            <td class="font-weight-medium text-warning">En attente</td>
                                            <?php elseif($item->statut == 2): ?>
                                            <td class="font-weight-medium text-danger">Inactif</td>
                                            <?php endif; ?>
                                            <td>

                                                <a href="<?php echo e(url('see-more-campagne/'.$item->id)); ?>" class="btn btn-warning rounded-0 text-white"><i class="ti-eye menu-icon"></i></a>

                                            </td>
                                        </tr>  
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                        </tbody>
                                    </table>
                                </div>
                                <div class="d-flex justify-content-center"> <?php echo $hisCampagnes->links(); ?></div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/admin/see-more.blade.php ENDPATH**/ ?>