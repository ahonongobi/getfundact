<?php $__env->startSection('content'); ?>


   
                <div class="row">
                    
                </div>
                <div class="row">
                    <?php if(Session::has('success')): ?>
                    <span class="btn btn-success rounded-0 text-white mr-3">
           
                <?php echo e(Session::get('success')); ?>

                    </span>
                    
                    <?php endif; ?>
                </div>
                <div class="row">

                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <p class="card-title mb-0">Utilisateurs</p>
                                <div class="table-responsive">
                                    <table class="table table-striped table-borderless">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Surname</th>
                                                <th>Date</th>
                                                <th>Statut</th>
                                                
                                                <th>Décision Jury 1 </th>
                                                <th>Décision Jury 2 </th>
                                                <th>Voir </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                            <td><?php echo e($item->name); ?></td>
                                            <td class="font-weight-bold"><?php echo e($item->surname); ?></td>
                                            <td><?php echo e($item->created_at); ?></td>
                                            <?php if($item->states ==1): ?>
                                            <td class="font-weight-medium text-success">Actif</td>
                                            <?php elseif($item->states ==0): ?>
                                            
                                            <td class="font-weight-medium text-warning">Inactif</td>
                                            <?php elseif($item->states == 2): ?>
                                            <td class="font-weight-medium text-danger">Supprimer</td>
                                            <?php endif; ?>
                                            
                                            <td class="d-flex justify-content-evenly">
                                                <a onclick="return confirm('Cette action est irreversible')" href="<?php echo e(url('delete/'.$item->id)); ?>"
                                                    class="btn btn-danger rounded-0 text-white mr-3"><i class="ti-trash"></i></a>

                                            </td>
                                            <?php if($item->states ==0): ?>
                                            <td>
                                                <a href="<?php echo e(url('valider/'.$item->id)); ?>"
                                                    class="btn btn-success rounded-0 text-white mr-3"><i class="ti-check"></i></a>

                                            </td>
                                            <?php else: ?>
                                            <td>
                                                <a href="<?php echo e(url('unvalider/'.$item->id)); ?>"
                                                    class="btn btn-danger rounded-0 text-white mr-3"><i class="ti-close"></i></a>

                                            </td>
                                            <?php endif; ?>
                                            <td>

                                                <a href="<?php echo e(url('see-more/'.$item->id)); ?>" class="btn btn-warning rounded-0 text-white"><i class="ti-eye"></i></a>

                                            </td>
                                        </tr>  
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                        </tbody>
                                    </table>
                                    <div class="d-flex justify-content"><?php echo $all_users->links(); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/admin/users.blade.php ENDPATH**/ ?>