<?php $__env->startSection('content'); ?>


   
                <div class="row">
                    
                </div>
                <div class="row">
                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <p class="card-title mb-0">Demande de retrait Aujourd'hui</p>
                                <div class="table-responsive">
                                    <table class="table table-striped table-borderless">
                                        <thead>
                                            <tr>
                                                <th>ID utilisateur</th>
                                                <th>ID campagne-Nom campagne</th>
                                                <th>Date</th>
                                                
                                                <th>Etat </th>
                                                <th>Action </th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $__currentLoopData = $all_withdraw_per_day; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                            <td><?php echo e($item->id_user); ?></td>
                                            <td class="font-weight-bold"><?php echo e($item->nom_campagne); ?></td>
                                            <td><?php echo e($item->created_at); ?></td>
                                            <?php if($item->statut ==1): ?>
                                            <td class="font-weight-medium text-success">Déja soldé</td>
                                            <?php elseif($item->statut ==0): ?>
                                            
                                            <td class="font-weight-medium text-warning">Pending</td>
                                            <?php elseif($item->statut == 2): ?>
                                            <td class="font-weight-medium text-danger">Cancelled</td>
                                            <?php endif; ?>
                                            <?php if($item->statut ==0): ?>
                                            <td>

                                                <a onclick="return confirm('Voulez vous vraiment confirmer le paiement?')" href="<?php echo e(url('pay/'.$item->id)); ?>" class="btn btn-danger rounded-0 text-white"><i class="ti-close"></i></a>

                                            </td>
                                            <?php endif; ?>

                                            <?php if($item->statut ==1): ?>
                                            <td>

                                                <a onclick="return confirm('Voulez vous vraiment annuler le paiement?')" href="<?php echo e(url('unpay/'.$item->id)); ?>" class="btn btn-warning rounded-0 text-white"><i class="ti-check"></i></a>

                                            </td>
                                            <?php endif; ?>
                                           
                                            
                                            
                                        </tr>  
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                            <div class="d-flex justify-content-center"><?php echo $all_withdraw->links(); ?></div>

                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <p class="card-title mb-0">Demande de retrait</p>
                                <div class="table-responsive">
                                    <table class="table table-striped table-borderless">
                                        <thead>
                                            <tr>
                                                <th>ID utilisateur</th>
                                                <th>ID campagne-Nom campagne</th>
                                                <th>Date</th>
                                                
                                                <th>Etat </th>
                                                <th>Action </th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                          <?php $__currentLoopData = $all_withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                            <td><?php echo e($item->id_user); ?></td>
                                            <td class="font-weight-bold"><?php echo e($item->nom_campagne); ?></td>
                                            <td><?php echo e($item->created_at); ?></td>
                                            <?php if($item->statut ==1): ?>
                                            <td class="font-weight-medium text-success">Déja soldé</td>
                                            <?php elseif($item->statut ==0): ?>
                                            
                                            <td class="font-weight-medium text-warning">Pending</td>
                                            <?php elseif($item->statut == 2): ?>
                                            <td class="font-weight-medium text-danger">Cancelled</td>
                                            <?php endif; ?>
                                            <?php if($item->statut ==0): ?>
                                            <td>

                                                <a onclick="return confirm('Voulez vous vraiment confirmer le paiement?')" href="<?php echo e(url('pay/'.$item->id)); ?>" class="btn btn-danger rounded-0 text-white"><i class="ti-close"></i></a>

                                            </td>
                                            <?php endif; ?>

                                            <?php if($item->statut ==1): ?>
                                            <td>

                                                <a onclick="return confirm('Voulez vous vraiment annuler le paiement?')" href="<?php echo e(url('unpay/'.$item->id)); ?>" class="btn btn-warning rounded-0 text-white"><i class="ti-check"></i></a>

                                            </td>
                                            <?php endif; ?>
                                           
                                            
                                            
                                        </tr>  
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                            <div class="d-flex justify-content-center"><?php echo $all_withdraw->links(); ?></div>

                        </div>
                    </div>

                </div>


            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('_layouts._admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/admin/withdarwal.blade.php ENDPATH**/ ?>