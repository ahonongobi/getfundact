<?php

namespace App\Http\Controllers;

use App\Models\Contrubution;
use App\Models\Profile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ContrubutionController extends Controller
{
    public function sendMoney(Request $request){
        $request->validate([
            'name'=>'required',
            'surname'=>'required',
            'email'=> 'required',
            'montant' => 'required',
            'numero'=> 'required',
            'inlineRadioOptions'=>'required',
        ]);
        //dd($request->id_author);
        $okToSendMoney = new Contrubution();
        $okToSendMoney->id_user = Auth::user()->id;
        $takeProfile = Profile::where('user_id',Auth::user()->id)->first();
        $okToSendMoney->id_campagnes = $request->id_campagne;
        $okToSendMoney->nom_du_porteur = $request->nom_du_porteur;
        $okToSendMoney->id_author = $request->id_author;
        $okToSendMoney->photo = $takeProfile->photo;
        $okToSendMoney->name = $request->name;
        $okToSendMoney->surname = $request->surname;
        $okToSendMoney->email = $request->email;
        $okToSendMoney->numero = $request->numero;
        $okToSendMoney->montant = $request->montant;
        $okToSendMoney->payment = $request->inlineRadioOptions;
        if ($okToSendMoney->save()) {
            $notification_gobi = array(
                'title' => 'Féliciations',
                'sending' => "Votre contribution est parvenue avec succès. Merci pour votre esprit de bénévolat au sein de la société.",
                'type' => 'success',
        
                );
                return back()->with($notification_gobi);
        }
        

    }
}
