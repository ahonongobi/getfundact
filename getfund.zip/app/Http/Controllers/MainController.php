<?php

namespace App\Http\Controllers;

use App\Models\Campagne;
use App\Models\Contrubution;
use Illuminate\Http\Request;

class MainController extends Controller
{
    public function view(){
        return view('about');
    }

    public function indexUserDash(){
        return view('user_dash.index');
    }

    public function indexCampagne(){
        return view('user_dash.campagne');
    }
    public function profile(){
        return view('user_dash.profile');
    }

    public function myCampagne(){
        return view('user_dash/my-campagne');
    }

    public function donationDetails($id,$name){
        $details = Campagne::where('id',$id)->first();
        $contributeur = Contrubution::where('id_campagnes',$id)->get();
        return view('user_dash.donation-details',compact('details','contributeur'));
    }
    public function donationDetailsOrg($id,$name){
        $details = Campagne::where('id',$id)->first();
        $contributeur = Contrubution::where('id_campagnes',$id)->get();
        return view('invest_dash.donation-details',compact('details','contributeur'));
    }

    public function contributions(){
        return view('user_dash.contribution');
    }
}
