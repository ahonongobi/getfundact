<!DOCTYPE html>
<html lang="zxx">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">

        <link rel="stylesheet" href="assets/css/icofont.min.css">

        <link rel="stylesheet" href="assets/css/meanmenu.css">

        <link rel="stylesheet" href="assets/css/modal-video.min.css">

        <link rel="stylesheet" href="assets/fonts/flaticon.css">

        <link rel="stylesheet" href="assets/css/animate.min.css">

        <link rel="stylesheet" href="assets/css/lightbox.min.css">

        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">

        <link rel="stylesheet" href="assets/css/odometer.min.css">

        <link rel="stylesheet" href="assets/css/nice-select.min.css">

        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="https://cdn.rawgit.com/t4t5/sweetalert/v0.2.0/lib/sweet-alert.css">

        <link rel="stylesheet" href="assets/css/responsive.css">
        <title>GetFund action, soutenez la communauté</title>
        <link rel="icon" type="image/png" href="assets/img/favicon.png">
    </head>
    <body>

        <div class="loader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="pre-box-one">
                        <div class="pre-box-two"></div>
                    </div>
                </div>
            </div>
        </div>


        <div class="user-form-area">
            <div class="container-fluid p-0">
                <div class="row m-0">
                    <div class="col-lg-6 p-0">
                        <div class="user-img">
                            <img src="assets/img/user-form-bg.jpg" alt="User">
                        </div>
                    </div>
                    <div class="col-lg-6 p-0">
                        <div class="user-content">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <div class="user-content-inner">
                                        <div class="top">
                                            <a href="/">
                                                <img src="assets/img/logo.png" alt="Logo">
                                            </a>
                                            <h2>CRÉATION DE COMPTE </h2>
                                        </div>
                                        <form method="POST" action="{{url('register') }}">
                                            @csrf
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="Personne">
                                                <label class="form-check-label" for="inlineRadio1">Personne</label>
                                            </div>
                                            <div class="form-check form-check-inline mb-2">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="Organisation">
                                                <label class="form-check-label" for="inlineRadio2">Organisation</label>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <input name="surname" value="{{ old('surname') }}" type="text" class="form-control" placeholder="Prénoms">
                                                        @if ($errors->has('surname'))
                                                        <span class="text-danger">{{  $errors->first('surname') }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <input type="text" value="{{ old('name') }}" name="name" class="form-control" placeholder="Nom">
                                                        @if ($errors->has('name'))
                                                        <span class="text-danger">{{  $errors->first('name') }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <input type="email" value="{{ old('email') }}" name="email" class="form-control" placeholder="E-mail">
                                                        @if ($errors->has('email'))
                                                        <span class="text-danger">{{  $errors->first('email') }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <input type="password"  name="password" class="form-control" placeholder="Mot de passe">
                                                        @if ($errors->has('password'))
                                                        <span class="text-danger">{{  $errors->first('password') }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <button type="submit" class="btn common-btn">CRÉER</button>
                                                </div>
                                            </div>
                                        </form>
                                        <div class="bottom">
                                            <p>DÉJÀ INSCRIT ?
                                                <a href="{{url('login')}}">SE CONNECTER</a>
                                            </p>
                                            <h4>OU</h4>
                                            <ul>
                                                <li><a href="{{url('auth/facebook') }}" target="_blank"><i class="icofont-facebook"></i>Se connecter avec facebook</a></li>
                                                <li><a href="{{ url('auth/google') }}"><i class="icofont-google-plus"></i>Se connetcer avec google</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="go-top">
            <i class="icofont-arrow-up"></i>
            <i class="icofont-arrow-up"></i>
        </div>


        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>

        <script src="assets/js/form-validator.min.js"></script>

        <script src="assets/js/contact-form-script.js"></script>

        <script src="assets/js/jquery.ajaxchimp.min.js"></script>

        <script src="assets/js/jquery.meanmenu.js"></script>

        <script src="assets/js/jquery-modal-video.min.js"></script>

        <script src="assets/js/wow.min.js"></script>

        <script src="assets/js/lightbox.min.js"></script>

        <script src="assets/js/owl.carousel.min.js"></script>

        <script src="assets/js/odometer.min.js"></script>
        <script src="assets/js/jquery.appear.min.js"></script>

        <script src="assets/js/jquery.nice-select.min.js"></script>

        <script src="assets/js/custom.js"></script>
        <script src="https://cdn.rawgit.com/t4t5/sweetalert/v0.2.0/lib/sweet-alert.min.js"></script>
        <script>
            function Abyssinie(){
          swal("{{Session::get('title')}}", "{{Session::get('sending')}}", "{{Session::get('type')}}");
     }
  
  $(document).ready(function(){

    @if(Session::has('sending')) {
      Abyssinie();
    } 
    @endif
    @if(!Session::has('sending')) {
      console.log('try to post');
    } 
    
    @endif
    
  })
    </script>
    </body>

</html>
