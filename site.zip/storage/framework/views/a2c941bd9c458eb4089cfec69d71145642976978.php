<?php $__env->startSection('content'); ?>
<style>
    .button-class{
        background-color: brown;
    }
</style>
<div class="container">
    <div class="feature-area two pb-70">
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-lg-8">
                    <div class="feature-item">
                        <i class="flaticon-donation"></i>
                        <h3>
                            <p href="#">Nom: <?php echo e($var_name); ?></p>
                        </h3>
                        <h3>
                            <a href="#">Prénoms: <?php echo e($var_surname); ?></a>
                        </h3>
                        <h3>
                            <a href="#">Email: <?php echo e($var_email); ?></a>
                        </h3>
                        <h3>
                            <a href="#">Montant: $<?php echo e($var_montant); ?></a>
                        </h3>
                        
                            <form action="<?php echo e(url('checkout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="amount" value="<?php echo e($var_montant); ?>">
                                <script
                                  src="https://cdn.fedapay.com/checkout.js?v=1.1.7"
                                  data-public-key="pk_sandbox_NTc9o_eAdlAxVYHVkq_kZXsy"
                                  data-button-text="Contribuer <?php echo e($var_montant); ?>"
                                  data-button-class="btn common-btn"
                                  data-transaction-amount="<?php echo e($var_montant); ?>"
                                  data-customer-firstname="<?php echo e($var_surname); ?>"
                                  data-customer-email="<?php echo e($var_email); ?>"
                                  data-customer-lastname="<?php echo e($var_name); ?>"
                                  data-transaction-description="Description de la transaction"
                                  data-currency-iso="XOF">
                                </script>
                               </form>
                    </div>
                </div>
                
                
            </div>
        </div>
    </div>
    
</div>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts._invest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/getfundafrica/resources/views/invest_dash/checkout.blade.php ENDPATH**/ ?>