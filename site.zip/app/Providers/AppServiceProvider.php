<?php

namespace App\Providers;

use App\Models\Campagne;
use App\Models\Contrubution;
use App\Models\Profile;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {

        Paginator::useBootstrap();
        View::composer(['index','invest_dash.index','invest_dash.donation-details','user_dash.donation-details','user_dash.my-campagne','invest_dash.campagne-org','user_dash.index','user_dash.contribution','invest_dash.contribution-org','_layouts._invest','_layouts._user'], function ($view){

            if (Auth::check()) {
                $view->with('campagnes', Campagne::where('user_id',Auth::user()->id)->get());
                $view->with('all_campagnes', Campagne::all());
                $view->with('contribution', Contrubution::where('id_author',Auth::user()->id)->paginate(10));
                $view->with('your_contribution', Contrubution::where('id_user',Auth::user()->id)->get());

                $view->with('count_your_contribution', Contrubution::where('id_user',Auth::user()->id)->count());
                $view->with('count_all_campagnes', Campagne::count());
                $view->with('count_your_contribution_amount', Contrubution::where('id_user',Auth::user()->id)->sum('montant'));

                $view->with('count_contribution_for_you', Contrubution::where('id_author',Auth::user()->id)->count());
                $view->with('count_all_campagnes', Campagne::count());
                $view->with('count_your_contribution_amount_for_you', Contrubution::where('id_author',Auth::user()->id)->sum('montant'));

                $view->with('check_if_user_complete_profile', Profile::where('user_id',Auth::user()->id)->count());


            }       
                 
            $view->with('all_campagnes', Campagne::all());
            $view->with('gallery',Campagne::all());
            
            


        });
    }
}
